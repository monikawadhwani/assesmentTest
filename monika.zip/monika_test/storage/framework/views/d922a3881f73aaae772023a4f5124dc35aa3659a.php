
    </body>
</html>
<?php /**PATH /var/www/html/monika_test/resources/views/layouts/footer.blade.php ENDPATH**/ ?>