            <div class="content col-sm-12">
                <div class="event_link"><a href="<?php echo e(url('/')); ?>">Events</a></div>
                <div class="title m-b-md">
                    <?php echo e($eventData->title); ?>

                </div>
                <p class="descCls"><?php echo e($eventData->description); ?></p>    
                <p>Location: <?php echo e($eventData->location); ?></p>
            
            </div>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/monika_test/resources/views/eventDetail.blade.php ENDPATH**/ ?>